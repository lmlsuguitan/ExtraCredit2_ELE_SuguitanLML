package ex02_ele_suguitanll.java;

public class Singer {
    String name;
    int noOfPerformances;
    int noOfPpl;
    double earnings;
    Song favoriteSong;
    
    public Singer (String n, int nop){
        name = n;
        noOfPerformances = nop;
        earnings = 0.0;
    }
    
    public void performForAudience (int numPpl){
        noOfPpl = numPpl;
        noOfPerformances++;
        earnings += noOfPpl * 100;
    }
    
    public void changeFavSong (Song newFavSong){
        favoriteSong = newFavSong;
    }
   
}
