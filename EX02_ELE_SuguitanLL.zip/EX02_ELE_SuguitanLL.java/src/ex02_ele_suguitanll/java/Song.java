package ex02_ele_suguitanll.java;

public class Song {
    String title;
    String artist;
    
    public Song (String t, String a){
        title = t;
        artist = a;
    }
}

