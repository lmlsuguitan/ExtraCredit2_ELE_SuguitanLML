package ex02_ele_suguitanll.java;

public class Producer {
    String name;
    double height;
    int age;
    
    public Producer (String n, double h, int a){
    name = n;
    height = h;
    age = a;
    }
}
