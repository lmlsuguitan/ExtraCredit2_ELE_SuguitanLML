package ex02_ele_suguitanll.java;

public class EX02_ELE_SuguitanLLJava {

    public static void main(String[] args) {
        
        Producer pd1 = new Producer ("Jack Antonoff", 1.80, 39);
        Producer pd2 = new Producer ("Benny Blanco", 1.73, 35);
        Producer pd3 = new Producer ("Max Martin", 1.73, 52);
        
        Song s1 = new Song ("Long Live", "Taylor Swift");
        Song s2 = new Song ("Backburner", "Niki");
        
        Singer singer = new Singer ("Zayn", 8);
     
        singer.performForAudience(12);
        singer.changeFavSong(s2);
       
        System.out.println (singer.name + " has performed for " + singer.noOfPerformances + " times!");
        System.out.println (singer.name + " has sang for " + singer.noOfPpl + " fans!");
        System.out.println ("He earned  " + singer.earnings + " and his new favorite song is " + s1.title + " by " + s1.artist + ".");
        
    }   
    
}
