import java.util.Scanner;

public class RockPaperScissors{
	public static void main(String[] args){
            
            Move rock = new Move("Rock");
            Move paper = new Move("Paper");
            Move scissors = new Move("Scissors");
            
            rock.setStrongAgainst(scissors);
            paper.setStrongAgainst(rock);
            scissors.setStrongAgainst(paper);
            
            Scanner scanner = new Scanner (System.in);
            
		int roundsToWin = 2;
                int playerScore = 0;
                int compScore = 0;
		
		while (true) {
                    System.out.println("Welcome to Rock, Paper, Scissors. Please choose an option:");
                    System.out.println("1. Start game");
                    System.out.println("2. Change number of rounds");
                    System.out.println("3. Exit application");
                    
                    int choice = scanner.nextInt();
                    scanner.nextLine();
                    
                    switch (choice){
                        case 1:
                            System.out.println("This match will be the first to " + roundsToWin + " wins.");
                            
                            while (playerScore < roundsToWin && compScore < roundsToWin){
                            
                                System.out.println("The computer has selected its move. Select your move:");
                                System.out.println("1. Rock");
                                System.out.println("2. Paper");
                                System.out.println("3. Scissors");
                            
                                int playerChoice = scanner.nextInt();
                                scanner.nextLine();
                            
                                Move playerMove = null;
                                Move compMove = null;
                            
                                switch (playerChoice){
                                    case 1:
                                        playerMove = rock;
                                        break;
                                    case 2:
                                        playerMove = paper;
                                        break;
                                    case 3:
                                        playerMove = scissors;
                                        break;
                                    default:
                                        System.out.println("Invalid Choice. Please choose 1, 2, or 3.");
                                        continue;
                                }
                            
                            int random = (int) Math.floor(Math.random() * 3) + 1;
                            
                            switch (random){
                                case 1 :
                                    compMove = rock;
                                    break;
                                case 2:
                                    compMove = paper;
                                    break;
                                case 3:
                                    compMove = scissors;
                                    break;
                            }
                            
                            int result = Move.compareMoves (playerMove, compMove);
                          
                            if (result == 0){
                                playerScore++;
                                System.out.println("Player chose " + playerMove.getName() + ". Computer chose " + compMove.getName() + ". Player wins round!");
                            } else if (result == 1){
                                compScore++;
                                System.out.println("Player chose " + playerMove.getName() + ". Computer chose " + compMove.getName() + ". Compuiter wins round!");
                            }
                            else {
                                System.out.println("Player chose " + playerMove.getName() + ". Computer chose " + compMove.getName() + ". Round is tied!");
                            }
                            
                            System.out.println("Player: " + playerScore + "- Computer: " + compScore);
                        }
                        
                        if (playerScore > compScore){
                            System.out.println("Player wins.");
                        } else {
                            System.out.println("Computer wins.");
                        }
                        
                        playerScore = 0;
                        compScore = 0;
                        break;
                        
                        case 2:
                            System.out.println("How many wins are needed to win a match?");
                            roundsToWin = scanner.nextInt();
                            scanner.nextLine();
                            System.out.println("New setting has been saved.");
                            break;
                            
                        case 3:
                            System.out.println("Thank you for playing!");
                            System.exit(0);
                            break;
                            
                        default:
                        System.out.println("Invalid choice. Please choose 1, 2, or 3.");
                        break;
                    }
                }
	}
}