package ex05_ele_suguitanlml;

import java.util.*;

public class Store {
  private final String name;
  private double earnings;
  private final ArrayList<Item> itemList;
  private static final ArrayList<Store> storeList = new ArrayList();

  public Store(String name){
    this.name = name;
    this.earnings = 0;
    itemList = new ArrayList();
    storeList.add (this);
  }

  public String getName(){
    return name;
  }
  public double getEarnings(){
    return earnings;
  }
  public void sellItem(int index){
      if (index < 0 || index >= itemList.size()){
        System.out.println("There are only " + itemList.size() + " items in the store. \n");
      }
      else {
          Item item = itemList.get(index);
          earnings += item.getCost();
          System.out.println("The item " + itemList.get(index).getName() + " has been sold for " + itemList.get(index).getCost() + "! \n");
      }
  }
  public void sellItem(String name){
    boolean found = false;
    for (Item i: itemList){
        if (i.getName().equals(name)){
            earnings += i.getCost();
            System.out.println("The item " + i.getName() + " has been sold for $" + i.getCost() + "!");
            found = true;
        }
    }
    if (!found) {
        System.out.println("Item does not exist in the store.");
    }
  }
  public void sellItem(Item i){
    if (itemList.contains (i)){
        earnings += i.getCost();
        System.out.println("The item " + i.getName() + " has been sold for " + i.getCost() + "!");
    }
    else {
    System.out.println("Item does not exist in the store.");
    }
  }
  public void addItem(Item i){
    itemList.add(i);
  }
  public void filterType(String type){
      System.out.println("Items of type: " + type);
    for (Item a: itemList){
        if (a.getType().equals(type)){
            System.out.println(a.getName());
        }
    }
  }
  public void filterCheap(double maxCost){
      System.out.println("Items with cost less than or equal to $" + maxCost);
    for (Item b: itemList){
        if (b.getCost() <= maxCost){
            System.out.println(b.getName());
        }
    }
  }
  public void filterExpensive(double minCost){
      System.out.println("Items with cost greater than or equal to $" + minCost);
    for (Item c: itemList){
        if (c.getCost() >= minCost){
            System.out.println(c.getName());
        }
    }
  }
  public static void printStats(){
    for (Store i: storeList){
        System.out.println("Store: " + i.getName() + ", Earnings: $" + i.getEarnings());
    }
  }
}
