package ex01_ele_suguitanll;

public class EX01_ELE_SuguitanLL {

public static void main(String[] args) {

String favgg = "Blackpink";
int debyr = 2016;
int yrac = 7;

String show = "Brooklyn 99";
int relyr = 2013;
int yrair = 8;

String ans1 = "null";

String mod = "Iphone 11";
int yrrel = 2019;
int yrpro = 3;

int diff = debyr - relyr;
if (yrrel > debyr){
    ans1 = "true";}
else{
    ans1 = "false";
}
int sum = yrac + yrair + yrpro;

System.out.println("KPop");
System.out.println("Favorite girl group: " + favgg);
System.out.println("Debut Year: " + debyr);
System.out.println("Number of years Active (as of present): " + yrac);
System.out.println();
System.out.println("TV Show");
System.out.println("Favorite TV show: " + show);
System.out.println("Release Year: " + relyr);
System.out.println("Number of years show has aired: " + yrair);
System.out.println();
System.out.println("Mobile Phone");
System.out.println("Model name: " + mod);
System.out.println("Release Year: " + yrrel);
System.out.println("Number of years of active production: " + yrpro);
System.out.println();
System.out.println("Number of years Brooklyn 99 was released before Blackpink debuted: " + diff + " years");
System.out.println("Iphone 11 is more recent than Blackpink: " + ans1);
System.out.println("Total number of years objects are active: " + sum);

}

}


