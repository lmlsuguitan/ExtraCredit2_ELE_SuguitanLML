//E X03_ELE_Suguitan
package ex03_ele_suguitan;

public class EX03_ELE_Suguitan {

    public static void main(String[] args) {
                
        Producer pd1 = new Producer ("Jack Antonoff", 1.80, 39);
        Producer pd2 = new Producer ("Benny Blanco", 1.73, 35);
        Producer pd3 = new Producer ("Max Martin", 1.73, 52);
        
        Song s1 = new Song ("Long Live", "Taylor Swift");
        Song s2 = new Song ("Backburner", "Niki");
        
        Singer sing1 = new Singer ("Zayn", 0, 0.0, s2);
        Singer sing2  = new Singer ("Adele", 0, 0.0, s2);
        
        sing1.performForAudience (12);
        sing1.changeFavSong(s1);
        sing1.performForAudience(8, sing2);
        int totalPerfs = sing1.getTotalPerformances();
        
        System.out.println("The amount of performances for both the singers are " + totalPerfs + "!");
    }  
  }
    
