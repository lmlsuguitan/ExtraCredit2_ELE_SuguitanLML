package ex03_ele_suguitan;

public class Singer {
    private String name;
    private int noOfPerformances;
    private double earnings;
    private Song favoriteSong;
    private static int totalPerfs = 0;
    
    public Singer (String n, int nop, double earn, Song favSong){
        name = n;
        noOfPerformances = nop;
        favoriteSong = favSong;
        earnings = earn;
    }
    
    public String getName(){
        return name;
    }
    
    public int getNoOfPerformances(){
        return noOfPerformances;
    }
    
    public double getEarnings(){
        return earnings;
    }
    
    public Song getFavoriteSong(){
        return favoriteSong;
    }
    
    public int getTotalPerformances(){
        return totalPerfs;
    }
    
    public void performForAudience (int numPpl){
        totalPerfs += noOfPerformances;
        noOfPerformances += numPpl;
        earnings = numPpl * 100;
        
        System.out.println(name + " performed " + noOfPerformances + " times and earned " + earnings + ".");
        
        totalPerfs += numPpl;
    }
    
    public void performForAudience (int numPpl, Singer twoSinger){
        int totalPpl = numPpl + twoSinger.getNoOfPerformances();
        double totalEarnings = numPpl * 100 + twoSinger.getEarnings();
        
        double eachSingEarnings = totalEarnings / 2;
        
        noOfPerformances += numPpl;
        earnings += eachSingEarnings;
        
        twoSinger.noOfPerformances += numPpl;
        twoSinger.earnings += eachSingEarnings;
        
        totalPerfs += numPpl;
        
        System.out.println(name + " and " + twoSinger.getName() +  " have performed for a total of " + totalPpl + " people.");
    }
    
    public void changeFavSong (Song newFavSong){
        favoriteSong = newFavSong;
        System.out.println("The new favorite song for the day is " + favoriteSong.getSongTitle() + ".");
    }
}
