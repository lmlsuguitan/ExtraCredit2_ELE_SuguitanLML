package ex03_ele_suguitan;

public class Song {
    private String title;
    private String artist;
    
    public Song (String t, String a){
        title = t;
        artist = a;
    }
    
    public String getSongTitle(){
        return title;
    }
    
    public String getSongArtist(){
        return artist;
    }
}
