package ex03_ele_suguitan;

public class Producer {
    private String name;
    private double height;
    private int age;
    
    public Producer (String n, double h, int a){
    name = n;
    height = h;
    age = a;
    }
}
